# Example Package
This is a trial to understand how creating packages work.